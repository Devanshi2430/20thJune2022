function demoExternalAlert(){
    alert('Your document is ready.');
}
function demoExternalConfirm(){
    confirm('Want to download?');
}
function demoExternalPrompt(){
    prompt('Enter Name');
}
function changeColor(){
    document.body.style.backgroundColor="Yellow";
}
function divChangeColor(){
    document.getElementById("D1").style.backgroundColor="Red";
}
function bodyBGDynamic(){
    document.body.style.backgroundColor=prompt("Enter color name here..");
}
function divBGDynamic(){
    document.getElementById("D1").style.backgroundColor=prompt("Enter color name here..");
}
function bodyBGCP1(){
    document.body.style.backgroundColor=document.getElementById("CP1").value;
}
function divBGCP2(){
    document.getElementById("D1").style.backgroundColor=document.getElementById("CP2").value;
}